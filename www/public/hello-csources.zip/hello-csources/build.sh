#! /bin/sh
# Generated from niminst
# Template is in tools/buildsh.tmpl
# To regenerate run ``niminst csource`` or ``koch csource``

set -e

while :
do
  case "$1" in
    --extraBuildArgs)
      extraBuildArgs=" $2"
      shift 2
      ;;
    --) # End of all options
      shift
      break;
      ;;
    -*)
      echo "Error: Unknown option: $1" >&2
      exit 1
      ;;
    *)  # No more options
      break
      ;;
  esac
done

CC="gcc"
LINKER="gcc"
COMP_FLAGS="-w -O3 -fno-strict-aliasing$extraBuildArgs"
LINK_FLAGS=""
# platform detection
ucpu=`uname -m`
uos=`uname`
# bin dir detection
binDir=bin

if [ -s ../koch.nim ]; then
  binDir="../bin"
fi

if [ ! -d $binDir ]; then
  mkdir $binDir
fi

# convert to lower case:
ucpu=`echo $ucpu | tr "[:upper:]" "[:lower:]"`
uos=`echo $uos | tr "[:upper:]" "[:lower:]"`

case $uos in
  *linux* ) 
    myos="linux" 
    LINK_FLAGS="$LINK_FLAGS -ldl -lm"
    ;;
  *dragonfly* )
    myos="freebsd"
    LINK_FLAGS="$LINK_FLAGS -lm"
    ;;
  *freebsd* )
    myos="freebsd"
    CC="clang"
    LINKER="clang"
    LINK_FLAGS="$LINK_FLAGS -ldl -lm"
    ;;
  *openbsd* )
    myos="openbsd" 
    LINK_FLAGS="$LINK_FLAGS -lm"
    ;;
  *netbsd* )
    myos="netbsd"
    LINK_FLAGS="$LINK_FLAGS -lm"
    ;;
  *darwin* ) 
    myos="macosx"
    CC="clang"
    LINKER="clang"
    LINK_FLAGS="$LINK_FLAGS -ldl -lm"
    if [ "$HOSTTYPE" = "x86_64" ] ; then
      ucpu="amd64"
    fi
    ;;
  *aix* )
    myos="aix"
    LINK_FLAGS="$LINK_FLAGS -ldl -lm"    
    ;;
  *solaris* | *sun* ) 
    myos="solaris"
    LINK_FLAGS="$LINK_FLAGS -ldl -lm -lsocket -lnsl"
    ;;
  *haiku* )
    myos="haiku"
    ;;
  *) 
    echo "Error: unknown operating system: $uos"
    exit 1
    ;;
esac

case $ucpu in
  *i386* | *i486* | *i586* | *i686* | *bepc* | *i86pc* ) 
    mycpu="i386" ;;
  *amd*64* | *x86-64* | *x86_64* ) 
    mycpu="amd64" ;;
  *sparc*|*sun* ) 
    mycpu="sparc" ;;
  *ppc64* ) 
    if [ "$myos" = "linux" ] ; then
      COMP_FLAGS="$COMP_FLAGS -m64"
      LINK_FLAGS="$LINK_FLAGS -m64"
    fi
    mycpu="powerpc64" ;;
  *power*|*Power*|*ppc* ) 
    mycpu="powerpc" ;;
  *mips* ) 
    mycpu="mips" ;;
  *arm*|*armv6l* )
    mycpu="arm" ;;
  *) 
    echo "Error: unknown processor: $ucpu"
    exit 1
    ;;
esac

# call the compiler:

case $myos in
windows) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/1_1/hello.c -o c_code/1_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/1_1/hello.c -o c_code/1_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/1_1/stdlib_system.c -o c_code/1_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/1_1/stdlib_system.c -o c_code/1_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/1_1/hello.o \
c_code/1_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/1_1/hello.o \
c_code/1_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/1_2/hello.c -o c_code/1_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/1_2/hello.c -o c_code/1_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/1_2/stdlib_system.c -o c_code/1_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/1_2/stdlib_system.c -o c_code/1_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/1_2/hello.o \
c_code/1_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/1_2/hello.o \
c_code/1_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  arm)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  sparc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  mips)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  powerpc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
linux) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_1/hello.c -o c_code/2_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_1/hello.c -o c_code/2_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_1/stdlib_system.c -o c_code/2_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_1/stdlib_system.c -o c_code/2_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/2_1/hello.o \
c_code/2_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/2_1/hello.o \
c_code/2_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_2/hello.c -o c_code/2_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_2/hello.c -o c_code/2_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_2/stdlib_system.c -o c_code/2_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_2/stdlib_system.c -o c_code/2_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/2_2/hello.o \
c_code/2_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/2_2/hello.o \
c_code/2_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_3/hello.c -o c_code/2_3/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_3/hello.c -o c_code/2_3/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_3/stdlib_system.c -o c_code/2_3/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_3/stdlib_system.c -o c_code/2_3/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/2_3/hello.o \
c_code/2_3/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/2_3/hello.o \
c_code/2_3/stdlib_system.o $LINK_FLAGS
    ;;
  arm)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_4/hello.c -o c_code/2_4/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_4/hello.c -o c_code/2_4/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_4/stdlib_system.c -o c_code/2_4/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_4/stdlib_system.c -o c_code/2_4/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/2_4/hello.o \
c_code/2_4/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/2_4/hello.o \
c_code/2_4/stdlib_system.o $LINK_FLAGS
    ;;
  sparc)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_5/hello.c -o c_code/2_5/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_5/hello.c -o c_code/2_5/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_5/stdlib_system.c -o c_code/2_5/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_5/stdlib_system.c -o c_code/2_5/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/2_5/hello.o \
c_code/2_5/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/2_5/hello.o \
c_code/2_5/stdlib_system.o $LINK_FLAGS
    ;;
  mips)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_6/hello.c -o c_code/2_6/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_6/hello.c -o c_code/2_6/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_6/stdlib_system.c -o c_code/2_6/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_6/stdlib_system.c -o c_code/2_6/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/2_6/hello.o \
c_code/2_6/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/2_6/hello.o \
c_code/2_6/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_7/hello.c -o c_code/2_7/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_7/hello.c -o c_code/2_7/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/2_7/stdlib_system.c -o c_code/2_7/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/2_7/stdlib_system.c -o c_code/2_7/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/2_7/hello.o \
c_code/2_7/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/2_7/hello.o \
c_code/2_7/stdlib_system.o $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
macosx) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/3_1/hello.c -o c_code/3_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/3_1/hello.c -o c_code/3_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/3_1/stdlib_system.c -o c_code/3_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/3_1/stdlib_system.c -o c_code/3_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/3_1/hello.o \
c_code/3_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/3_1/hello.o \
c_code/3_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/3_2/hello.c -o c_code/3_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/3_2/hello.c -o c_code/3_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/3_2/stdlib_system.c -o c_code/3_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/3_2/stdlib_system.c -o c_code/3_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/3_2/hello.o \
c_code/3_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/3_2/hello.o \
c_code/3_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/3_3/hello.c -o c_code/3_3/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/3_3/hello.c -o c_code/3_3/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/3_3/stdlib_system.c -o c_code/3_3/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/3_3/stdlib_system.c -o c_code/3_3/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/3_3/hello.o \
c_code/3_3/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/3_3/hello.o \
c_code/3_3/stdlib_system.o $LINK_FLAGS
    ;;
  arm)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  sparc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  mips)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  powerpc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
solaris) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/4_1/hello.c -o c_code/4_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/4_1/hello.c -o c_code/4_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/4_1/stdlib_system.c -o c_code/4_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/4_1/stdlib_system.c -o c_code/4_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/4_1/hello.o \
c_code/4_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/4_1/hello.o \
c_code/4_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/4_2/hello.c -o c_code/4_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/4_2/hello.c -o c_code/4_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/4_2/stdlib_system.c -o c_code/4_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/4_2/stdlib_system.c -o c_code/4_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/4_2/hello.o \
c_code/4_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/4_2/hello.o \
c_code/4_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  arm)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  sparc)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/4_5/hello.c -o c_code/4_5/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/4_5/hello.c -o c_code/4_5/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/4_5/stdlib_system.c -o c_code/4_5/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/4_5/stdlib_system.c -o c_code/4_5/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/4_5/hello.o \
c_code/4_5/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/4_5/hello.o \
c_code/4_5/stdlib_system.o $LINK_FLAGS
    ;;
  mips)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  powerpc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
freebsd) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/5_1/hello.c -o c_code/5_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/5_1/hello.c -o c_code/5_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/5_1/stdlib_system.c -o c_code/5_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/5_1/stdlib_system.c -o c_code/5_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/5_1/hello.o \
c_code/5_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/5_1/hello.o \
c_code/5_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/5_2/hello.c -o c_code/5_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/5_2/hello.c -o c_code/5_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/5_2/stdlib_system.c -o c_code/5_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/5_2/stdlib_system.c -o c_code/5_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/5_2/hello.o \
c_code/5_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/5_2/hello.o \
c_code/5_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  arm)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  sparc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  mips)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  powerpc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
netbsd) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/6_1/hello.c -o c_code/6_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/6_1/hello.c -o c_code/6_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/6_1/stdlib_system.c -o c_code/6_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/6_1/stdlib_system.c -o c_code/6_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/6_1/hello.o \
c_code/6_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/6_1/hello.o \
c_code/6_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/6_2/hello.c -o c_code/6_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/6_2/hello.c -o c_code/6_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/6_2/stdlib_system.c -o c_code/6_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/6_2/stdlib_system.c -o c_code/6_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/6_2/hello.o \
c_code/6_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/6_2/hello.o \
c_code/6_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  arm)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  sparc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  mips)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  powerpc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
openbsd) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/7_1/hello.c -o c_code/7_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/7_1/hello.c -o c_code/7_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/7_1/stdlib_system.c -o c_code/7_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/7_1/stdlib_system.c -o c_code/7_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/7_1/hello.o \
c_code/7_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/7_1/hello.o \
c_code/7_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/7_2/hello.c -o c_code/7_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/7_2/hello.c -o c_code/7_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/7_2/stdlib_system.c -o c_code/7_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/7_2/stdlib_system.c -o c_code/7_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/7_2/hello.o \
c_code/7_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/7_2/hello.o \
c_code/7_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  arm)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  sparc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  mips)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  powerpc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
haiku) 
  case $mycpu in
  i386)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/8_1/hello.c -o c_code/8_1/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/8_1/hello.c -o c_code/8_1/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/8_1/stdlib_system.c -o c_code/8_1/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/8_1/stdlib_system.c -o c_code/8_1/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/8_1/hello.o \
c_code/8_1/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/8_1/hello.o \
c_code/8_1/stdlib_system.o $LINK_FLAGS
    ;;
  amd64)
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/8_2/hello.c -o c_code/8_2/hello.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/8_2/hello.c -o c_code/8_2/hello.o
    echo "$CC $COMP_FLAGS -Ic_code -c c_code/8_2/stdlib_system.c -o c_code/8_2/stdlib_system.o"
    $CC $COMP_FLAGS -Ic_code -c c_code/8_2/stdlib_system.c -o c_code/8_2/stdlib_system.o
    echo "$LINKER -o $binDir/hello  \
c_code/8_2/hello.o \
c_code/8_2/stdlib_system.o $LINK_FLAGS"
    $LINKER -o $binDir/hello  \
c_code/8_2/hello.o \
c_code/8_2/stdlib_system.o $LINK_FLAGS
    ;;
  powerpc64)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  arm)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  sparc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  mips)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  powerpc)
    echo "$LINKER -o $binDir/hello  $LINK_FLAGS"
    $LINKER -o $binDir/hello  $LINK_FLAGS
    ;;
  *)
    echo "Error: no C code generated for: [$myos: $mycpu]"
    exit 1
    ;;
  esac
  ;;
*) 
  echo "Error: no C code generated for: [$myos: $mycpu]"
  exit 1
  ;;
esac

echo "SUCCESS"

